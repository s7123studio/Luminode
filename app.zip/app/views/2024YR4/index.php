<!DOCTYPE html>
<html>
<head>
    <title>2024YR4 Asteroid Tracker</title>
    <style>
        #timer {
            text-align: center;
            font-size: 2em;
            margin: 20px;
        }
        #canvas {
            border: 1px solid black;
        }
    </style>
</head>
<body>
    <div id="timer"></div>
    <canvas id="canvas" width="800" height="600"></canvas>

    <script>
        // 天文常数
        const AU = 149597870.7; // 1 AU in km
        const DAY_SECONDS = 86400;
        
        // 轨道计算参数
        <?php
        $result = $sql->query("SELECT * FROM asteroids WHERE name='2024YR4'");
        $asteroid = $result->fetch_assoc();
        echo "const ASTEROID = ".json_encode($asteroid).";";
        ?>

        // 倒计时定时器
        function updateTimer() {
            const target = new Date('2032-12-22T00:00:00');
            const now = new Date();
            const diff = target - now;
            
            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const seconds = Math.floor((diff % (1000 * 60)) / 1000);
            
            document.getElementById('timer').innerHTML = 
                `${days}d ${hours}h ${seconds}s`;
        }
        setInterval(updateTimer, 1000);

        // 轨道计算
        class OrbitalCalculator {
            constructor() {
                this.canvas = document.getElementById('canvas');
                this.ctx = this.canvas.getContext('2d');
                this.scale = 80; // 1 AU = 80 pixels
            }

            // 计算小行星位置
            calculateAsteroidPosition() {
                const perihelionDate = new Date(ASTEROID.perihelion_date);
                const now = new Date();
                const timeSincePerihelion = (now - perihelionDate) / 1000; // in seconds
                
                // 轨道参数
                const a = ASTEROID.semi_major_axis * AU; // km
                const e = ASTEROID.eccentricity;
                const T = ASTEROID.orbital_period * 365 * DAY_SECONDS; // seconds
                
                // 平近点角计算
                const M = (2 * Math.PI * timeSincePerihelion) / T;
                
                // 解开普勒方程（简化版）
                let E = M;
                for(let i = 0; i < 10; i++) {
                    E = M + e * Math.sin(E);
                }
                
                // 真近点角
                const theta = 2 * Math.atan(
                    Math.sqrt((1+e)/(1-e)) * Math.tan(E/2)
                );
                
                // 极坐标转笛卡尔坐标
                const r = (a * (1 - e*e)) / (1 + e * Math.cos(theta));
                return {
                    x: r * Math.cos(theta),
                    y: r * Math.sin(theta)
                };
            }

            // 计算地球位置（简化圆形轨道）
            calculateEarthPosition() {
                const now = new Date();
                const daysSinceYearStart = (now - new Date(now.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24);
                const angle = (daysSinceYearStart / 365) * 2 * Math.PI;
                return {
                    x: AU * Math.cos(angle),
                    y: AU * Math.sin(angle)
                };
            }

            // 绘制轨道
            draw() {
                this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
                
                // 绘制太阳
                this.ctx.beginPath();
                this.ctx.arc(400, 300, 10, 0, 2 * Math.PI);
                this.ctx.fillStyle = 'yellow';
                this.ctx.fill();

                // 绘制地球
                const earthPos = this.calculateEarthPosition();
                this.ctx.beginPath();
                this.ctx.arc(
                    400 + earthPos.x/AU * this.scale,
                    300 + earthPos.y/AU * this.scale,
                    5, 0, 2 * Math.PI
                );
                this.ctx.fillStyle = 'blue';
                this.ctx.fill();

                // 绘制小行星
                const asteroidPos = this.calculateAsteroidPosition();
                this.ctx.beginPath();
                this.ctx.arc(
                    400 + asteroidPos.x/AU * this.scale,
                    300 + asteroidPos.y/AU * this.scale,
                    3, 0, 2 * Math.PI
                );
                this.ctx.fillStyle = 'red';
                this.ctx.fill();
            }
        }

        // 初始化并运行动画
        const calculator = new OrbitalCalculator();
        setInterval(() => calculator.draw(), 1000);
    </script>
</body>
</html>